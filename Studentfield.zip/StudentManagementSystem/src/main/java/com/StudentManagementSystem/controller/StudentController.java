package com.StudentManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.StudentManagementSystem.entity.student;
import com.StudentManagementSystem.service.StudentService1;

@RestController
public class StudentController {
	@Autowired
	StudentService1 service;
	
	@GetMapping("/info")
	public List<student> getStudentData() {
List<student>list=service.getStudentData();
return list;
	}
	@PostMapping("/insertstud")
	public String insertStudentinfo(@RequestBody student s1) {
	String msg=service.insertStudentinfo(s1);
	return msg;
		
	}
	@PutMapping("/updatestud")
	public String updateStudentInfo(@RequestBody student s2) {
		String msg    = service.updateStudentInfo(s2);
		return msg;
	}
	@DeleteMapping("/deletestud/{id}")
	public String deleteStudentInfo(@PathVariable int id) {
	String msg=	  service. deleteStudentInfo(id) ;
	return msg;
	}
	@GetMapping("/getstudname")
	public List<String> getStudentName() {
		List<String>list=  service.getStudentName();
		return list;
	}
	@GetMapping("/getstudemail")
	public List<String> getStudentEmail() {
		List<String>list=service.getStudentEmail();
		return list;
	}
	
}
