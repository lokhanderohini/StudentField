package com.StudentManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentManagementSystem.dao.StudentDao;
import com.StudentManagementSystem.entity.student;

@Service
public class StudentService1 {
@Autowired
StudentDao dao;
	public List<student> getStudentData() {
		List<student>list=dao.getStudentData();
		return list;
	}
	public String insertStudentinfo(student s1) {
String msg=dao. insertStudentinfo(s1);

		return msg;
	}
	public String updateStudentInfo(student s2) {
	String msg=	dao.updateStudentInfo(s2) ;
	
		return msg;
	}
	public String deleteStudentInfo(int id) {
	String msg=	   dao.deleteStudentInfo(id);
		return msg;
	}
	public List<String> getStudentName() {
	List<String>	list=dao.getStudentName();
		return list;
	}
	public List<String> getStudentEmail() {
		List<String> list=dao.getStudentEmail();
		return list;
	}

}
