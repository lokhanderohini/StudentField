package com.StudentManagementSystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.StudentManagementSystem.entity.student;
@Repository
public class StudentDao {
@Autowired
SessionFactory sf;
	
	public List<student> getStudentData() {
Session session=sf.openSession();
Criteria criteria=session.createCriteria(student.class);
return criteria.list();
	}

	public String insertStudentinfo(student s1) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(s1);
		transaction.commit();
		session.close();
		return "Student inserted sucessfully.....";
	}

	public String updateStudentInfo(student s2) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.update(s2);
		transaction.commit();
		return "Student updated sucessfully....";
	}

	public String deleteStudentInfo(int id) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		student stud1=  session.load(student.class, id);
		session.delete(stud1);
		transaction.commit();
		return "Student deleted sucessfully";
		
	}

	public List<String> getStudentName() {
		Session session=sf.openSession();
		Criteria criteria=session.createCriteria(student.class);
	List<student>sss= criteria.list();
	List<String>list=new ArrayList<>();
	for(student st:sss ) {
		list.add(st.getFirstname());
		
	}
		return list;
	}

	public List<String> getStudentEmail() {
		Session session=sf.openSession();
		Criteria criteria=session.createCriteria(student.class);
		List<student>stu=criteria.list();
		List<String>list=new ArrayList<>();
		for(student stu1:stu) {
			list.add(stu1.getEmail());
		}
		return list;
		}
	}

	
	


